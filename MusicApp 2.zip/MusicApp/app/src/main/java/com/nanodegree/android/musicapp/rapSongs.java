package com.nanodegree.android.musicapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class rapSongs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rap_songs);

        TextView rapsong1  = (TextView) findViewById(R.id.rapSong1);
        TextView rapsong2  = (TextView) findViewById(R.id.rapSong2);
        rapsong1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){
                Intent rapMusic = new Intent(rapSongs.this, NowPlaying.class);
                startActivity(rapMusic);
            }
        });
        rapsong2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){
                Intent rapMusic = new Intent(rapSongs.this, NowPlaying.class);
                startActivity(rapMusic);
            }
        });
    }
}

