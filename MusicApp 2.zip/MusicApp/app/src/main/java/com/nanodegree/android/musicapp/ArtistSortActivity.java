package com.nanodegree.android.musicapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ArtistSortActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artist_sort);
    }
}
