package com.nanodegree.android.musicapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

/**
 * Created by jdifuntorum on 10/16/16.
 */

public class MusicGenreActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_genre);

        TextView Hiphop  = (TextView) findViewById(R.id.hiphop);
        TextView Rap = (TextView) findViewById(R.id.rap);

        Hiphop.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){
                Intent hipHopSongs = new Intent(MusicGenreActivity.this, songsHipHop.class);
                startActivity(hipHopSongs);
            }


        });
        Rap.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){
                Intent rapSongs = new Intent(MusicGenreActivity.this, rapSongs.class);
                startActivity(rapSongs);
            }

        });
    }
}
