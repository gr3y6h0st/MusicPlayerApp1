package com.nanodegree.android.musicapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Library extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library);

        TextView genre = (TextView) findViewById(R.id.music_genre_sort);
        TextView artist = (TextView) findViewById(R.id.artist_button);

        genre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent genreActivity = new Intent(Library.this, MusicGenreActivity.class);
                startActivity(genreActivity);
            }
        });

        artist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent artistActivity = new Intent(Library.this, ArtistSortActivity.class);
                startActivity(artistActivity);
            }
        });
    }
}
