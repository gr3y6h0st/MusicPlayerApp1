package com.nanodegree.android.musicapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class songsHipHop extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_songs_hip_hop);

        TextView hipHopsong1  = (TextView) findViewById(R.id.hiphopSong1);
        TextView hipHopsong2  = (TextView) findViewById(R.id.hiphopSong2);
        hipHopsong1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){
                Intent hipHopSongs = new Intent(songsHipHop.this, NowPlaying.class);
                startActivity(hipHopSongs);
            }
        });
        hipHopsong2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){
                Intent hipHopSongs = new Intent(songsHipHop.this, NowPlaying.class);
                startActivity(hipHopSongs);
            }
        });
    }
}
